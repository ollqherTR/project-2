
class Details {
  late int price;
  late String name;
  late String image;
  Details({
    required this.price,
    required this.name,
    required this.image,
  });
}